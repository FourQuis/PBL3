﻿namespace UserPage
{
    partial class Dangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btDangnhap = new Guna.UI2.WinForms.Guna2Button();
            this.btDangky = new Guna.UI2.WinForms.Guna2Button();
            this.txtpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btqmk = new Guna.UI2.WinForms.Guna2Button();
            this.txtdn = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btDangnhap
            // 
            this.btDangnhap.AutoRoundedCorners = true;
            this.btDangnhap.BackColor = System.Drawing.Color.Transparent;
            this.btDangnhap.BorderRadius = 21;
            this.btDangnhap.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.btDangnhap.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btDangnhap.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btDangnhap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btDangnhap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btDangnhap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btDangnhap.ForeColor = System.Drawing.Color.White;
            this.btDangnhap.Location = new System.Drawing.Point(406, 236);
            this.btDangnhap.Name = "btDangnhap";
            this.btDangnhap.Size = new System.Drawing.Size(107, 45);
            this.btDangnhap.TabIndex = 0;
            this.btDangnhap.Text = "Đăng nhập";
            this.btDangnhap.Click += new System.EventHandler(this.btDangnhap_Click);
            // 
            // btDangky
            // 
            this.btDangky.AutoRoundedCorners = true;
            this.btDangky.BorderRadius = 21;
            this.btDangky.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btDangky.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btDangky.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btDangky.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btDangky.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btDangky.ForeColor = System.Drawing.Color.White;
            this.btDangky.Location = new System.Drawing.Point(541, 236);
            this.btDangky.Name = "btDangky";
            this.btDangky.Size = new System.Drawing.Size(124, 45);
            this.btDangky.TabIndex = 0;
            this.btDangky.Text = "Đăng ký";
            this.btDangky.Click += new System.EventHandler(this.btDangky_Click);
            // 
            // txtpass
            // 
            this.txtpass.Animated = true;
            this.txtpass.AutoRoundedCorners = true;
            this.txtpass.BorderRadius = 17;
            this.txtpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpass.DefaultText = "";
            this.txtpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Italic);
            this.txtpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass.Location = new System.Drawing.Point(456, 160);
            this.txtpass.Name = "txtpass";
            this.txtpass.PasswordChar = '*';
            this.txtpass.PlaceholderText = "Mật khẩu";
            this.txtpass.SelectedText = "";
            this.txtpass.Size = new System.Drawing.Size(200, 36);
            this.txtpass.TabIndex = 1;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(309, 92);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(126, 24);
            this.guna2HtmlLabel1.TabIndex = 2;
            this.guna2HtmlLabel1.Text = "Tên đăng nhập";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(309, 172);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(83, 24);
            this.guna2HtmlLabel2.TabIndex = 2;
            this.guna2HtmlLabel2.Text = "Mật khẩu";
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::UserPage.Properties.Resources.Screenshot_2022_04_27_100500;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 58);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(203, 125);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 3;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // btqmk
            // 
            this.btqmk.AutoRoundedCorners = true;
            this.btqmk.BackColor = System.Drawing.Color.Transparent;
            this.btqmk.BorderRadius = 21;
            this.btqmk.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.btqmk.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btqmk.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btqmk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btqmk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btqmk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btqmk.ForeColor = System.Drawing.Color.White;
            this.btqmk.Location = new System.Drawing.Point(428, 321);
            this.btqmk.Name = "btqmk";
            this.btqmk.Size = new System.Drawing.Size(125, 45);
            this.btqmk.TabIndex = 4;
            this.btqmk.Text = "Quên mật khẩu";
            // 
            // txtdn
            // 
            this.txtdn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdn.DefaultText = "";
            this.txtdn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtdn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtdn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdn.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdn.Location = new System.Drawing.Point(456, 92);
            this.txtdn.Name = "txtdn";
            this.txtdn.PasswordChar = '\0';
            this.txtdn.PlaceholderText = "Tên tài khoản";
            this.txtdn.SelectedText = "";
            this.txtdn.Size = new System.Drawing.Size(200, 36);
            this.txtdn.TabIndex = 1;
            // 
            // Dangnhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 378);
            this.Controls.Add(this.btqmk);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtdn);
            this.Controls.Add(this.btDangky);
            this.Controls.Add(this.btDangnhap);
            this.Name = "Dangnhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dangnhap";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btDangnhap;
        private Guna.UI2.WinForms.Guna2Button btDangky;
        private Guna.UI2.WinForms.Guna2TextBox txtpass;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btqmk;
        private Guna.UI2.WinForms.Guna2TextBox txtdn;
    }
}