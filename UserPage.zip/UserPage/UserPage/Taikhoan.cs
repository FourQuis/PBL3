﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserPage
{
    class Taikhoan
    {
        private string tentk;
        private string mk;
        
        public Taikhoan(string tentk, string mk)
        {
            this.tentk = tentk;
            this.mk = mk;
        }

        public string Tentk { get => tentk; set => tentk = value; }
        public string Mk { get => mk; set => mk = value; }
    }
}
