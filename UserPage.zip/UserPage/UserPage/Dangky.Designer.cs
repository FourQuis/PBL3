﻿namespace UserPage
{
    partial class Dangky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btdk = new Guna.UI2.WinForms.Guna2Button();
            this.txt_dktdn = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtdk_mk = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtdk_xnmk = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtdk_email = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btdk
            // 
            this.btdk.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btdk.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btdk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btdk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btdk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btdk.ForeColor = System.Drawing.Color.White;
            this.btdk.Location = new System.Drawing.Point(336, 306);
            this.btdk.Name = "btdk";
            this.btdk.Size = new System.Drawing.Size(180, 45);
            this.btdk.TabIndex = 0;
            this.btdk.Text = "Đăng ký";
            this.btdk.Click += new System.EventHandler(this.btdk_Click);
            // 
            // txt_dktdn
            // 
            this.txt_dktdn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_dktdn.DefaultText = "";
            this.txt_dktdn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_dktdn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_dktdn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_dktdn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_dktdn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_dktdn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_dktdn.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_dktdn.Location = new System.Drawing.Point(336, 86);
            this.txt_dktdn.Name = "txt_dktdn";
            this.txt_dktdn.PasswordChar = '\0';
            this.txt_dktdn.PlaceholderText = "Tên đăng nhập";
            this.txt_dktdn.SelectedText = "";
            this.txt_dktdn.Size = new System.Drawing.Size(200, 36);
            this.txt_dktdn.TabIndex = 1;
            // 
            // txtdk_mk
            // 
            this.txtdk_mk.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdk_mk.DefaultText = "";
            this.txtdk_mk.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtdk_mk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtdk_mk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_mk.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_mk.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_mk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtdk_mk.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_mk.Location = new System.Drawing.Point(336, 147);
            this.txtdk_mk.Name = "txtdk_mk";
            this.txtdk_mk.PasswordChar = '\0';
            this.txtdk_mk.PlaceholderText = "Nhập mật khẩu";
            this.txtdk_mk.SelectedText = "";
            this.txtdk_mk.Size = new System.Drawing.Size(200, 36);
            this.txtdk_mk.TabIndex = 1;
            // 
            // txtdk_xnmk
            // 
            this.txtdk_xnmk.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdk_xnmk.DefaultText = "";
            this.txtdk_xnmk.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtdk_xnmk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtdk_xnmk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_xnmk.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_xnmk.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_xnmk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtdk_xnmk.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_xnmk.Location = new System.Drawing.Point(336, 189);
            this.txtdk_xnmk.Name = "txtdk_xnmk";
            this.txtdk_xnmk.PasswordChar = '\0';
            this.txtdk_xnmk.PlaceholderText = "Nhập lại mật khẩu";
            this.txtdk_xnmk.SelectedText = "";
            this.txtdk_xnmk.Size = new System.Drawing.Size(200, 36);
            this.txtdk_xnmk.TabIndex = 1;
            // 
            // txtdk_email
            // 
            this.txtdk_email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdk_email.DefaultText = "";
            this.txtdk_email.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtdk_email.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtdk_email.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_email.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtdk_email.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_email.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtdk_email.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtdk_email.Location = new System.Drawing.Point(336, 231);
            this.txtdk_email.Name = "txtdk_email";
            this.txtdk_email.PasswordChar = '\0';
            this.txtdk_email.PlaceholderText = "Email";
            this.txtdk_email.SelectedText = "";
            this.txtdk_email.Size = new System.Drawing.Size(200, 36);
            this.txtdk_email.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(173, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tên đăng nhập";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mật khẩu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(173, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Xác nhận mật khẩu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(183, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Email";
            // 
            // Dangky
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdk_email);
            this.Controls.Add(this.txtdk_xnmk);
            this.Controls.Add(this.txtdk_mk);
            this.Controls.Add(this.txt_dktdn);
            this.Controls.Add(this.btdk);
            this.Name = "Dangky";
            this.Text = "Dangky";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btdk;
        private Guna.UI2.WinForms.Guna2TextBox txt_dktdn;
        private Guna.UI2.WinForms.Guna2TextBox txtdk_mk;
        private Guna.UI2.WinForms.Guna2TextBox txtdk_xnmk;
        private Guna.UI2.WinForms.Guna2TextBox txtdk_email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}