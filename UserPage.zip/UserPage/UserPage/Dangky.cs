﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace UserPage
{
    public partial class Dangky : Form
    {
        public Dangky()
        {
            InitializeComponent();
        }
        public bool checktk(string tk)
        {
            return Regex.IsMatch(tk, "^[a-zA-z0-9]{6,24}$");
        }
        public bool checkemail(string email)
        {
            return Regex.IsMatch(email, @"^[a-zA-z0-9_.]{3,20}@gmail.com(.vn|)$");

        }
      
        private void btdk_Click(object sender, EventArgs e)
        {
            string tk = txt_dktdn.Text;
            string mk = txtdk_mk.Text;
            string xmk = txtdk_xnmk.Text;
            string emaila = txtdk_email.Text;
            Modify modifi = new Modify();
            if (!checktk(tk))
            {
                MessageBox.Show("Vui lòng nhập tên tài khoản 6 - 24 ký tự","Thông báo");
                return;
            }
            if (!checktk(mk))
            {
                MessageBox.Show("Vui lòng nhập tên tài khoản 6 - 24 ký tự", "Thông báo");
                return;
            }
            if (!checkemail(emaila))
            {
                MessageBox.Show("Vui lòng nhập đúng dạng email ", "Thông báo");
                return;
            }
            if (mk != xmk)
            {
                MessageBox.Show("Vui lòng xác nhận mật khẩu chính xác", "Thông báo");
            }
            if (modifi.getTaikhoan("Select * from Taikhoan where Email = '" + emaila +"'" )!= null) 
            {
                MessageBox.Show("Email này đã đươc đăng ký , vui lòng đắng ký Email khác ", "Thông báo");
                return;
            }
            try
            {
                string query = "Insert into Taikhoan values ('"+tk+"','"+mk+"','"+emaila+"')";
                modifi.comad(query);
                if (MessageBox.Show("Đăng ký thành công ! Bạn có đăng nhập luôn không","Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information)==DialogResult.Yes)
                {
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Tên tài khoản và mật khẩu đã được đăng ký , vui lòng đăng ký tài khoản khác");
            }
            
        }

    }
}
