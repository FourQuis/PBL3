﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace UserPage
{
    class Modify
    {
        public Modify()
        {

        }
        SqlCommand sqlCommand;
        SqlDataReader reader;
        public Taikhoan getTaikhoan(string query)
        {
            Taikhoan taikhoan = null;
            using (SqlConnection cnn = Connection.GetSqlConnection())
            {
                cnn.Open();
                
                sqlCommand =  new SqlCommand(query,cnn);
                reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                     taikhoan = new Taikhoan(reader.GetString(0),reader.GetString(1));
                 
                }
                cnn.Close();
            }
            return taikhoan;
        }
        public void comad(string query)
        {
            using (SqlConnection cnn = Connection.GetSqlConnection())
            {
                cnn.Open();

                sqlCommand = new SqlCommand(query, cnn);
                sqlCommand.ExecuteNonQuery();
        
                cnn.Close();
            }
        }
    }
}
