﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UserPage
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }

        
        private void btDangnhap_Click(object sender, EventArgs e)
        {   Modify modify = new Modify();
            string tentk = txtdn.Text;
            string mk = txtpass.Text;
            string query = "Select * from Taikhoan where taikhoan = '"+tentk+"' and matkhau = '"+mk+"'";
          
            if (tentk.Trim() == "" )
            {
                MessageBox.Show("Vui lòng nhập tên tài khoản", "Thông báo");
                return;
            }
            else if (mk.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu", "Thông báo");
                return;
            }
            else if (modify.getTaikhoan(query) != null)
            {
                MessageBox.Show("Bạn đã đăng nhập thành công", "Thông báo");
                Main main = new Main();
                main.ShowDialog();
            }
            else
            {
                MessageBox.Show("Bạn đã nhập sai tài khoản mật khẩu", "Thông báo");

            }

        }

        private void btDangky_Click(object sender, EventArgs e)
        {
            Dangky dk = new Dangky();
            dk.ShowDialog();
        }
    }
}
